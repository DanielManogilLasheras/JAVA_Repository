package model.enums;

public enum Trama{
    Misterio("Misterio"),
    Intriga("Intriga");

    Trama(String trama){
    }

}

