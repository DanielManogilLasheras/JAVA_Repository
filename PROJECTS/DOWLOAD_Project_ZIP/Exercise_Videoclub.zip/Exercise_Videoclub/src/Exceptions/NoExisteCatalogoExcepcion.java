package Exceptions;

public class NoExisteCatalogoExcepcion extends Exception{
    public NoExisteCatalogoExcepcion (String message){
        super(message);
    }
}
