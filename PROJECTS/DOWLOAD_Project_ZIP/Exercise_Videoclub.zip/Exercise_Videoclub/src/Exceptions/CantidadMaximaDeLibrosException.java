package Exceptions;

public class CantidadMaximaDeLibrosException extends Exception{
public CantidadMaximaDeLibrosException (String message){
    super(message);
}
}
