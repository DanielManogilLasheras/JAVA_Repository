package Exceptions;

public class LibroEnBusquedaNoEncontradoException extends Exception{
    public LibroEnBusquedaNoEncontradoException(){
        super();
    }
}
